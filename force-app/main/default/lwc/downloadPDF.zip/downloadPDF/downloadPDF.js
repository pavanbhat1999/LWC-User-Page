import { LightningElement } from 'lwc';
import jsPDFLibrary from '@salesforce/resourceUrl/jsPDFLibrary';
import { loadScript } from 'lightning/platformResourceLoader';
import uploadPdfFileAndSendEmail from '@salesforce/apex/PDFUploader.uploadPdfFileAndSendEmail'; // Import the modified Apex method

export default class DownloadPDF extends LightningElement {
    jsPDFInitialized = false;
    recipientEmail = 'prbhat07@gmail.com'; // Store recipient email

    // Rendered Callback to Load jsPDF
    renderedCallback() {
        if (!this.jsPDFInitialized) {
            this.jsPDFInitialized = true;
            loadScript(this, jsPDFLibrary)
                .then(() => {
                    console.log('jsPDF library loaded successfully');
                })
                .catch((error) => {
                    console.log('Error loading jsPDF library', error);
                });
        }
    }

    // Capture the recipient's email input
    handleEmailChange(event) {
        this.recipientEmail = event.target.value;
    }

    // Generate PDF and send it via email
    generatePDF() {
        if (this.jsPDFInitialized) {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();
            doc.text('Hello world!', 10, 10);
            const pdfOutput = doc.output('blob'); // Get the PDF blob object

            const reader = new FileReader();
            reader.onloadend = () => {
                const base64PDF = reader.result.split(',')[1]; // Get base64 encoded PDF
                // Call Apex to upload the base64 PDF and send an email
                uploadPdfFileAndSendEmail({ 
                    base64String: base64PDF, 
                    fileName: 'sample.pdf', 
                    recipientEmail: this.recipientEmail // Send recipient's email to Apex
                })
                .then(() => {
                    console.log('PDF uploaded and email sent successfully');
                })
                .catch((error) => {
                    console.log('Error uploading PDF and sending email', error);
                });
            };
            reader.readAsDataURL(pdfOutput); // Read the blob as Data URL
        }
    }
}
